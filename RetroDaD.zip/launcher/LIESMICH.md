# RetroDaD 3.33

> **Neu in 3.12 – aufgeräumter Ordner:** Programm, Emulatoren, Cover, Logs, Steuerung, Switch-Dateien, Updates und Werkzeuge liegen jetzt in **`bin`**, alle Einstellungsdateien (`.json`) in **`bin\jsons`**. Oben bleiben nur `Spiele`, `Spielstaende`, `Musik`, `RetroDaD.exe` und diese LIESMICH. Eine ältere Installation sortiert RetroDaD beim ersten Start selbst um – es wird nur verschoben, nichts gelöscht, und alle gespeicherten Pfade (eigene Cover, Titel, Favoriten …) ziehen mit. Die alten Programmdateien liegen danach zur Sicherheit in `bin\Updates\vorher-umbau-<Datum>`.
>
> **Updates:** Einstellungen → Allgemein → *RetroDaD-Update*, oder die neue `RetroDaD.zip` ungeöffnet nach `bin\Updates` legen und RetroDaD starten.

Eine Oberfläche für alle deine Emulatoren: Spiele in einer Reihe, Konsole mit ↑/↓ wechseln, Start mit Enter.
Bedienbar mit Tastatur, Maus und Controller (Xbox, PlayStation, Nintendo Switch Pro Controller).

---

## Schnellstart
1. **Python 3** installieren (python.org, beim Setup „Add python.exe to PATH“ anhaken).
2. **`RetroDaD.exe`** doppelklicken. Beim allerersten Start erscheint kurz ein schwarzes Fenster, das `pywebview` einrichtet und sich danach selbst schließt. Ab dann startet RetroDaD immer ohne dieses Fenster. (Wer `bin\werkzeuge\start.bat` direkt startet, sieht das Fenster die ganze Zeit – das ist der Modus mit Fehleranzeige.)
   - Windows kann beim ersten Mal „Der Computer wurde durch Windows geschützt“ melden, weil die Datei nicht signiert ist: „Weitere Informationen“ → „Trotzdem ausführen“.
   - Einstellungen → Allgemein → „Verknüpfung: Anlegen“ legt RetroDaD mit Symbol auf den Desktop und ins Startmenü.
   - `start.bat` liegt im Ordner `bin\werkzeuge`: Sie zeigt Fehlermeldungen an, falls RetroDaD einmal nicht startet. Selbst starten musst du sie nie.
   - Dateien aus älteren Versionen (`launcher.py`, `ui`, `werkzeuge`, `start.bat` direkt im RetroDaD-Ordner) räumt RetroDaD beim ersten Start selbst nach `bin\Updates\vorher-umbau-<Datum>`.
3. In RetroDaD **Menü → „Emulatoren installieren“** (gelber Knopf). Ohne RetroDaD geht es auch mit `bin\werkzeuge\Emulatoren installieren.bat`. Lädt alle Emulatoren aus offiziellen Quellen.
4. Spiele in den passenden Ordner unter **`Spiele\`** legen, dann Menü → „Spiele neu einlesen“.
5. Systemdateien deiner eigenen Konsolen ergänzen, wo nötig (siehe unten).

---

## Ordner
```
RetroDaD\
  RetroDaD.exe      starten
  LIESMICH.md
  Spiele\           GameBoy  GBA  NDS  NES  SNES  N64  MegaDrive  PS1  PS2  PS3  PS4  PS5  Wii  GameCube  Switch  Xbox  Xbox360
  Spielstaende\     RetroArch-Spielstände je Profil
  Musik\            eigene Musik fürs Menü (MP3, OGG, M4A, WAV, FLAC)
  bin\              alles, was RetroDaD selbst braucht:
    launcher.py     das Programm (setzt nur zusammen und startet)
    retrodad\       die Programmteile nach Themen (Bibliothek, Start, Jugendschutz, Leistung, Switch …)
    ui\             Oberfläche: index.html, stil.css, js\ (Logik nach Themen), Erfolgsbilder
    werkzeuge\      start.bat, Emulator-Installation, Programmtests
    Emulatoren\     RetroArch  Dolphin  Eden  Lichii  PCSX2  RPCS3  shadPS4  KytyPS5  xemu  Xenia
    covers\         heruntergeladene und eigene Cover
    logs\           Ausgabe des letzten Spielstarts je Konsole, Diagnose-Berichte, retrodad.log (kleine Pannen)
    steuerung\      erzeugte Tastenbelegungen für RetroArch
    Switch-Dateien\ prod.keys und Firmware deiner Switch
    Updates\        hier neue RetroDaD.zip ablegen – wird beim Start eingespielt
    jsons\          Einstellungen: config.json, zustand.json, anpassungen.json, steuerung.json, version.json
```
Unterordner sind erlaubt. Besonderheiten:
- **Switch**: `.nsp`/`.xci` oder entpackt als `<Spiel>\exefs\main` + `<Spiel>\romfs\`. Switch-2-Spiele (ID `0400…`) werden ausgeblendet.
- **Switch 2 (Lichii)**: `.nup`, `.nsp` oder `.xci`. Die Datei braucht eine Endung – Dateien ohne Endung werden nicht erkannt.
- **PS3 / PS4 / PS5**: ein Ordner pro Spiel (`…\PS3_GAME\USRDIR\EBOOT.BIN` bzw. `…\eboot.bin`), bei PS5 auch eine `.zar`-Datei. Bei PS4/PS5 holt RetroDaD Name und Symbol aus dem Spiel selbst (`sce_sys`), Ordner wie `PPSA01341` sind also kein Problem.
- **PS4 oder PS5?** Beide haben eine `eboot.bin`. Liegt ein Spiel im falschen Ordner, sagt RetroDaD es vor dem Start (PS5: `sce_sys\param.json`, PS4: `sce_sys\param.sfo`).

## Konsolen und Emulatoren
| Konsole | Emulator |
|---|---|
| Game Boy / Color, GBA, Nintendo DS, NES, SNES, N64, Mega Drive, PS1 | RetroArch (Cores: Gambatte, mGBA, melonDS DS, Mesen, Nestopia, FCEUmm, Snes9x, bsnes, Mupen64Plus-Next, Genesis Plus GX, Beetle PSX HW) |
| Wii / GameCube | Dolphin |
| Switch | Eden |
| Switch 2 (experimentell) | Lichii |
| PS2 | PCSX2 |
| PS3 | RPCS3 |
| PS4 | shadPS4 |
| PS5 (experimentell) | KytyPS5 |
| Xbox | xemu |
| Xbox 360 | Xenia Canary |

Xbox One / Series: Dafür gibt es keinen spielbaren Emulator.

**Systemdateien** stammen immer von deinen eigenen Konsolen. Ein Download ist dafür nicht vorgesehen.
Nötig sind sie für PS1 und PS2 (BIOS), Xbox (BIOS, MCPX-Bootrom und Festplatten-Abbild) und Switch (Keys und Firmware).
Die PS3-Firmware gibt es offiziell bei Sony.

**Installer**: `bin\werkzeuge\emulatoren_installieren.ps1` prüft zuerst, was vorhanden ist, und lädt nur Fehlendes.
`-Aktualisieren` bringt alle auf den neuesten Stand, `-Nur Dolphin,PCSX2` beschränkt die Installation auf einzelne Emulatoren.

---

## Bedienung
| | Tastatur | Controller | Maus |
|---|---|---|---|
| Spiel wählen | ← → | Steuerkreuz / Stick | Klick, Mausrad |
| Konsole wechseln | ↑ ↓ | Steuerkreuz / Stick | Pfeile oder Punkte links |
| Starten | Enter | A | Klick auf das gewählte Spiel |
| Details | I | X → Details | Klick auf den Spieltitel |
| Optionen | O | X | Rechtsklick auf die Kachel |
| Favorit | F | X → Favorit | Rechtsklick |
| Sortieren | R | X → Reihe sortieren | Klick auf „Name A–Z“ |
| Suchen | / oder Strg+F | R (oben) → Suchleiste | in die Suchleiste oben klicken |
| Zufallsspiel | Z | R → Würfel | Würfel oben rechts |
| Erfolge | E | R → Orden | Orden oben rechts |
| Homebrew-Store | H | R → Tasche | Tasche oben rechts |
| Steuerung | S | Menü | Menü |
| Menü | Tab / M | Y / + / Start | „Menü“ unten links |
| Zurück | Esc | B | Klick daneben |

Oben rechts liegen **Zufallsspiel, Erfolge und Homebrew-Store**. Am Controller springt **R** (rechte Schultertaste) dorthin, ◂ ▸ wählt, A öffnet, B oder ▾ geht zurück zu den Spielen.

Beim **Pro Controller** gilt die Nintendo-Belegung: A rechts bestätigt, B unten geht zurück.
Ist `pygame-ce` installiert (passiert beim ersten Start), liest RetroDaD die Controller selbst über SDL statt über den Browser-Baustein. Das ist zuverlässiger: Vorher konnte der Pro Controller im Menü nach einem RetroArch-Spiel „verschwinden“.

**Zurück zu RetroDaD während des Spiels:** **Select + Start** eine Sekunde halten, beim Pro Controller **− und +**.
Der Emulator wird sauber geschlossen, so als würdest du das Fenster schließen. Reagiert er nicht, wird er nach einigen Sekunden hart beendet.
Das funktioniert mit allen Emulatoren und braucht `pygame-ce`, das beim ersten Start mitinstalliert wird.

**Weiterspielen:** Bei den RetroArch-Konsolen wird beim Beenden automatisch gespeichert, und beim nächsten Start geht es genau dort weiter.

**Fernseher-Modus:** Größere Kacheln und Schrift, Start im Vollbild. Auf Wunsch startet RetroDaD mit Windows.
Beides findest du unter Einstellungen → Allgemein.

## Bibliothek
- **Zuletzt gespielt** steht immer ganz oben, danach **Favoriten**. Dann kommen die Konsolen mit Spielen alphabetisch, zuletzt die ohne Spiele.
- **Zufallsspiel** (Würfel oben rechts oder Taste **Z**): RetroDaD wählt ein Spiel aus allen Konsolen aus und springt dorthin. Gestartet wird es erst, wenn du willst.
- **Spielzeit**: Konsole, Spielzeit und das Datum des letzten Spiels stehen unter dem Titel. Gezählt wird ab 20 Sekunden Spieldauer.
- **Sortieren** pro Konsole: Name A–Z, Zuletzt gespielt, Meistgespielt oder Favoriten zuerst.
- **Suche** über alle Konsolen – die Suchleiste steht immer oben in der Mitte. **Details** zeigt Cover, Spielzeit, Emulator und Core, Größe, Herkunft und Speicherort.

## Profile
Oben links steht, wer gerade spielt. Ein Klick darauf, die Taste **P** oder Menü → „Profil wechseln“ öffnet die Profilwahl.
- Jedes Profil hat eigene **Favoriten**, eigene **Spielzeit**, eigenes **„Zuletzt gespielt“** und eigene **Sortierung**.
- **Spielstände**: Jedes Profil hat eigene Spielstände – bei allen Konsolen.
  - RetroArch-Konsolen: in `Spielstaende\<Profil>`.
  - Dolphin, PCSX2, Eden, Lichii, RPCS3, shadPS4, Xenia: RetroDaD legt vor dem Start die Spielstand-Ordner des aktiven Profils bereit. Die Ordner der anderen Profile werden nur umbenannt (z. B. `GC.retrodad-p2`), nie gelöscht, und die tägliche Sicherung nimmt sie mit. Dafür muss der Emulator geschlossen sein – ist er noch offen, sagt RetroDaD Bescheid.
  - Das erste Profil übernimmt alle bisherigen Spielstände. Spielstände, die ein anderes Profil vor 3.9 bei Dolphin, PCSX2 & Co. angelegt hat, liegen deshalb beim ersten Profil.
  - Einstellungen → „Eigene Spielstände pro Profil“ ausschalten: Dann teilen sich alle die Spielstände des ersten Profils.
- Profile lassen sich **anlegen**, **umbenennen** und **entfernen**. Beim Entfernen bleiben die Spielstände auf der Festplatte liegen.

## Leistungsmodus

RetroDaD erkennt Grafikkarte und Arbeitsspeicher und wählt passende Einstellungen für die Emulatoren (Einstellungen → Reiter **Leistung**):

- **Sparsam** (schwächere PCs, Onboard-Grafik): native Auflösung, Shader werden im Hintergrund vorbereitet.
- **Ausgewogen**: doppelte Auflösung bei GameCube/Wii (Dolphin) und PS2 (PCSX2).
- **Beste Qualität** (starke Grafikkarte, ab 16 GB RAM): dreifache Auflösung, bei NES/SNES/Game Boy/Mega Drive weniger Eingabeverzögerung („Run-Ahead“).
- **Automatisch** nimmt, was zu deinem PC passt. **Aus** lässt alle Emulator-Einstellungen in Ruhe.

Was dabei passiert:
- Dolphin bekommt die Werte nur für den jeweiligen Start mit – deine eigenen Einstellungen bleiben unverändert. RetroArch ebenso.
- Bei PCSX2 (Auflösung) und Eden/Lichii (Shader im Hintergrund und Shader-Speicher) ändert RetroDaD nur diese einzelnen Werte in der Einstellungsdatei; beim ersten Mal wird eine Kopie `….launcher-sicherung` angelegt.
- **Starke Grafikkarte**: Bei PCs und Laptops mit zwei Grafikchips sucht RetroDaD zuerst, welche Karte die starke ist – egal ob NVIDIA, AMD Radeon oder Intel Arc. Gefragt wird dafür Windows selbst (welche Karte es bei „Hohe Leistung“ nimmt); geht das nicht, entscheidet der Name (Onboard-Grafik wie Intel UHD/Iris/Arc Graphics oder AMD Radeon 780M wird erkannt). Die gefundene Karte steht in den Einstellungen und im Selbsttest. Dann trägt RetroDaD jeden Emulator in Windows für „Hohe Leistung“ ein (wie Windows-Einstellungen → Grafik). Gibt es nur eine Karte oder keine eindeutig stärkere, ändert RetroDaD nichts. Eine eigene Wahl dort wird nie überschrieben; beim Ausschalten nimmt RetroDaD nur seine eigenen Einträge zurück.
- **Höchstleistung beim Spielen**: Solange ein Spiel läuft, ist der Windows-Energiesparplan auf „Höchstleistung“ und der Emulator hat Vorrang vor Hintergrundprogrammen. Danach wird der vorherige Plan wiederhergestellt. Gibt es den Plan auf deinem PC nicht, bleibt alles, wie es ist.
- **Empfohlene Einstellungen pro Spiel**: Für einzelne Spiele lädt RetroDaD beim Start die Einstellungen, die sich bei Testern bewährt haben – als Lichii-/Eden-Einstellungen *nur für dieses Spiel* (`config\custom\<Spiel-ID>.ini`), deine allgemeinen Einstellungen bleiben unberührt. Bisher dabei (Werte aus Lichiis Quellcode und den Testberichten der Entwickler und Nutzer):
  - **Zelda: Ocarina of Time (Remake)** in Lichii: GPU-Modus „Fast“ (am wichtigsten – das Spiel bremst vor allem den Prozessor), Shader und Bildausgabe im Hintergrund, Reactive Flushing aus, CPU-Genauigkeit „Unsafe“, CPU-Takt „Normal“ (sonst läuft das eingebaute Dynamic FPS zu schnell), Texturen und Videos auf der Grafikkarte, FSR-Filter. Auflösung je Leistungsstufe: Sparsam 0,75×, Ausgewogen 1×, Beste Qualität 1,5×.
  - **Mario Kart World**: GPU-Modus „Fast“, GPU-Takt „Boost“ (behebt die 30-FPS-Sperre), CPU-Takt „Normal“, 1× Auflösung (das Spiel rendert selbst 1440p), VSync „FIFO Relaxed“, Texturen auf der Grafikkarte (BC3), Pokal-Videos auf dem Prozessor, kein zusätzliches Kantenglätten. Sparsam: Handheld-Modus (1080p), Bilinear-Filter und „dynamic FPS“ (passt sich zwischen 30 und 60 FPS an); Ausgewogen: TV-Modus, FSR, dynamic FPS; Beste Qualität: TV-Modus, FSR, feste 60 FPS.
  - **Donkey Kong Bananza**: dieselben Grundwerte (GPU-Modus „Fast“, 1×, Boost, FIFO Relaxed); Sparsam im Handheld-Modus. Das Spiel schaltet selbst zwischen 60, 30 und 20 FPS – auch mit diesen Einstellungen sind Einbrüche normal.
  - **Yoshi and the Mysterious Book** (auch Demo): die bewährten Grundwerte. Achtung: Die 3D-Welt ist erst mit einer Lichii-Korrektur sichtbar, die am 11.11.2026 noch nicht in einer veröffentlichten Version war – bis dahin bleibt die Welt schwarz. Menü → Einstellungen → Emulator-Updates holt sie, sobald sie erscheint.
  - **Switch-1-Spiele in Eden**: Zelda (Breath of the Wild, Tears of the Kingdom, Link’s Awakening, Skyward Sword HD, Echoes of Wisdom, Hyrule Warriors: Zeit der Verheerung und Definitive Edition, Cadence of Hyrule), Kirby und das vergessene Land, Yoshi’s Crafted World und **alle Mario-Spiele der Switch**: Odyssey, Wonder, 3D World + Bowser’s Fury, 3D All-Stars, Galaxy 1 und 2, New Super Mario Bros. U Deluxe, Maker 2, Bros. 35, RPG, Paper Mario (Origami King, Äonentor), Mario & Luigi: Brothership, Mario Kart 8 Deluxe, Super Mario Party, Party Superstars, Party Jamboree, Tennis Aces, Golf: Super Rush, Strikers, Mario vs. Donkey Kong, Mario & Sonic Tokyo 2020, Mario + Rabbids (Kingdom Battle, Sparks of Hope), Captain Toad, Luigi’s Mansion 2 HD und 3, Princess Peach: Showtime! Für alle: Shader im Hintergrund, Shader-Speicher, Texturen auf der Grafikkarte, VSync „FIFO Relaxed“, CPU-Takt „Normal“.
    - **Pokémon**: Let’s Go Pikachu/Evoli, Schwert/Schild, Strahlender Diamant/Leuchtende Perle, Legenden: Arceus, Karmesin/Purpur, Legenden: Z-A, Mystery Dungeon DX, New Pokémon Snap, Pokkén DX, Meisterdetektiv Pikachu kehrt zurück, Café ReMix, Quest, Feuerrot/Blattgrün – und **Pokopia** (Switch 2, in Lichii). Die CPU-Genauigkeit bleibt bei allen auf „Auto“ („Unsafe“ lässt Karmesin/Purpur abstürzen). Arceus, Karmesin/Purpur und Z-A laufen als schwere Spiele (1×/1×/2×), aber ab „Ausgewogen“ mit GPU-Modus „Accurate“ – mit „Fast“ werden dort Bäume und Figuren falsch gezeichnet.
    - Leichte Spiele (Link’s Awakening, Skyward Sword, Echoes of Wisdom, Odyssey, Mario Kart 8, Kirby …): Sparsam 1× im Handheld-Modus mit GPU-Modus „Fast“; Ausgewogen 2× und Beste Qualität 3× im TV-Modus mit GPU-Modus „Accurate“ (weniger Grafikfehler, kostet bei Switch-1-Spielen wenig).
    - Schwere Spiele (Breath of the Wild, Tears of the Kingdom, Zeit der Verheerung, Luigi’s Mansion 3, Mario + Rabbids Sparks of Hope): immer GPU-Modus „Fast“, Sparsam 1× Handheld, Ausgewogen 1× TV, Beste Qualität 2× TV. Tears of the Kingdom bekommt zusätzlich mehr Konsolenspeicher (6 bzw. 8 GB, Eden empfiehlt mindestens 6 GB) und platzsparende Texturen (BC3).
    - Erkannt wird an der Spiel-ID im Dateinamen oder – wenn keine drinsteht – am Spielnamen (z. B. „Super Mario Odyssey v1.3.0.xci“).
  - Die Lichii-Zusätze „Dynamic FPS“ und „Max Resolution“ (Rechtsklick aufs Spiel → Eigenschaften → Add-Ons) bleiben an. Sieht etwas falsch aus, dort einzeln ausschalten.
  - Abschalten: Einstellungen → „Empfohlene Einstellungen pro Spiel“ oder Leistungsmodus „Aus“.
- **Lichii**: Ist zu wenig Speicher da (RAM + Auslagerungsdatei unter 20 GB), erscheint vor dem Start ein Hinweis, wie du die Auslagerungsdatei vergrößerst.

**Weitere Bremsen, die RetroDaD löst** (alles im Reiter Leistung):
- **Lichii baut Shader vorab**: Bei den Switch-2-Spielen mit Profil (Ocarina of Time, Mario Kart World, Bananza, Yoshi, Pokopia) bereitet Lichii die Shader auf dem Ladebildschirm vor – keine Ruckler mehr, wenn ein Effekt zum ersten Mal kommt. Der allererste Start dauert dafür ein paar Minuten (überspringbar), danach geht es schnell.
- **RetroDaD ruht, solange ein Spiel läuft**: keine Animationen, kein Weichzeichner, Controller-Abfrage nur noch 4× pro Sekunde statt 60× – so bleibt die ganze Leistung beim Spiel, auch wenn RetroDaD nicht minimiert ist.
- **Leichte Oberfläche**: ohne Weichzeichner und mit kurzen Animationen – automatisch an bei „Sparsam“.
- **NVIDIA-Shader-Cache** (nur mit NVIDIA-Grafikkarte): ein Knopf stellt im NVIDIA-Treiber die „Shader-Cache-Größe“ auf **Unbegrenzt** – wie in der NVIDIA-Systemsteuerung unter 3D-Einstellungen. Sonst wirft der Treiber alte Shader weg, und die Emulatoren müssen sie neu bauen (Ruckler). Weil der Treiber das nur mit Administratorrechten speichert, erscheint einmal die Windows-Rückfrage. „Zurück auf Standard“ stellt den Treiberwert wieder her. Ohne NVIDIA-Karte zeigt RetroDaD nur einen Hinweis.
- **Windows-Check**: zeigt, ob der Windows-Spielmodus und die hardwarebeschleunigte GPU-Planung an sind, und öffnet die passende Windows-Einstellung. RetroDaD ändert dort selbst nichts.

## Statistik

Oben rechts das rosa Balken-Symbol (Taste **T**): Spielzeit der letzten 7 und 30 Tage, insgesamt, meistgespielte Spiele, Zeit pro Konsole und ein Vergleich aller Profile der letzten Woche. ◀ ▶ wechselt das Profil. Die Tageswerte werden ab dieser Version gesammelt; die Gesamtzeit pro Spiel gab es schon vorher.

## Kinder-Ansicht
Für Kinderprofile gibt es eine vereinfachte Oberfläche: größere Kacheln, oben rechts die **Restzeit als Balken** (⏳ grün → orange in den letzten 10 Minuten, 🌙 vor der Schlafenszeit), im Menü nur Profil, Mathe, Hell/Dunkel, Vollbild und Beenden. Einstellungen, Steuerung, Aufräumen, Statistik und der Store sind ausgeblendet, im Spielmenü gibt es nur Spielen, Details und Favorit.
Eltern stellen sie pro Kind ein (Sanduhr → Profil → **Kinder-Ansicht**): *Automatisch* (an, sobald das Profil Regeln hat), *An* oder *Aus*.

**Bilder statt Text:** Ist die Spielzeit um, erscheint eine leere Sanduhr; zur Schlafenszeit ein schlafender Mond. Zehn Minuten vor der Schlafenszeit zeigt RetroDaD einmal den Mond mit Countdown – „such dir noch ein kurzes Spiel aus“.

## Spielzeit mit Mathe verdienen

Eltern schalten es pro Kind ein: Sanduhr → Profil → **Mathe-Bonus: Ein**, dazu **Alter** eingeben. RetroDaD stellt daraus die Klasse ein (Alter − 5, also 10 Jahre → Klasse 5); mit **Klasse − / +** lässt sie sich anpassen, z. B. nach einer Einschulung mit 7 oder beim Überspringen. Außerdem einstellbar: wie viele Minuten eine Runde bringt (5/10/15) und wie viele höchstens pro Tag (15–60).

**Wo das Kind rechnet:** türkiser Mathe-Knopf oben rechts (Taste **B**), Menü → türkiser Knopf „Mathe – Spielzeit verdienen“, oder automatisch angeboten, wenn die Spielzeit abläuft. Bonuszeit gibt es nur, wenn das Kind ein Tageslimit hat – ohne Limit sind es Übungsrunden.

**Beim Start:** War zuletzt dein (geschütztes) Profil aktiv, startet RetroDaD mit dem zuletzt benutzten Kinderprofil – sonst könnte ein Kind einfach neu starten. Zu deinem Profil geht es oben links mit der PIN.

**Schutz:** Sobald ein Kind den Mathe-Bonus (oder ein Limit, eine Schlafenszeit, eine Spielefreigabe) hat, lassen sich Profile ohne Regeln – z. B. deins – nur noch mit der Eltern-PIN öffnen. Wer dein Profil verlässt, braucht für die Rückkehr wieder die PIN.

So läuft es: Es gibt eine Runde mit **5 Aufgaben**:
- 2 × **Basis** aus dem Stoff der Vorklasse (Sicherheit), 2 × **Standard** auf Klassenniveau, 1 × **Challenge** (Transfer).
- Vier Antworten zur Auswahl; die falschen sind typische Fehler (Übertrag vergessen, Vorzeichen, Punkt vor Strich …).
- Falsche Antwort → **Tippkarte 1** (Denkanstoß), dann **Tippkarte 2** (konkreter Schritt), danach der **Lösungsweg**. Eine Aufgabe zählt, wenn sie mit höchstens einer Tippkarte gelöst wurde.
- Mit **4 von 5** gibt es die Bonuszeit. Nie über die Schlafenszeit hinaus.

Themen (Auszug): Kl. 1–2 Plus/Minus bis 20 und 100, Einmaleins · Kl. 3–4 Einmaleins, Teilen mit Rest, Größen, schriftliches Malnehmen, Stellenwerte · Kl. 5–6 Punkt vor Strich, Teiler, Flächen, Brüche, Dezimalzahlen · Kl. 7–8 negative Zahlen, Prozent, Terme, Dreisatz, Gleichungen, Steigung, binomische Formeln, Wahrscheinlichkeit · Kl. 9–10 Pythagoras, Potenzen, Wurzeln, Wachstum, Trigonometrie · Oberstufe Ableitungen, Stammfunktionen, Vektoren.

*Prüfvermerk:* Die Zuordnung der Themen zu den Klassen orientiert sich an den niedersächsischen Kerncurricula Mathematik (Grundschule, Sek I, Sek II), ist aber eine Annäherung – die Kerncurricula legen die Kompetenzen am Ende der Doppeljahrgänge fest, die genaue Reihenfolge regelt der Arbeitsplan der Schule. Bitte bei Bedarf mit dem Arbeitsplan abgleichen und die Klasse im Profil anpassen.

## Spielzeit & Jugendschutz
Menü → Sanduhr (oder in der Profilwahl „Spielzeit begrenzen …“).

**Einrichten:**
1. Eine 4-stellige **Eltern-PIN** wählen und wiederholen.
2. Eine **E-Mail-Adresse** für „PIN vergessen“ angeben.
3. Den angezeigten **Notfall-Code** aufschreiben. Er wird nur einmal angezeigt.

**Spielzeit pro Profil:**
- Für jedes Profil getrennt **Montag–Freitag** und **Samstag/Sonntag**: unbegrenzt, „kein Spielen“ oder 15 Minuten bis 5 Stunden.
- Die Zeit zählt nur, solange ein Spiel läuft (auch bei „Emulator ohne Spiel öffnen“). Um Mitternacht beginnt ein neuer Tag.
- Oben neben dem Namen steht die Restzeit.
- **10, 5 und 1 Minute vorher** kommt ein Hinweis. In RetroArch erscheint er als Bildschirmtext, bei den anderen Emulatoren als kleines Fenster oben.
- Ist die Zeit um, wird das Spiel wie mit Select + Start beendet. Bei den RetroArch-Konsolen speichert „Weiterspielen“ vorher automatisch.
- **Mehr Zeit** für heute geben Eltern mit der PIN: im Spielzeit-Fenster (+15 / +30 Min.) oder direkt in der Meldung „Spielzeit aufgebraucht“.

**Schlafenszeit pro Profil:**
- Zwei Uhrzeiten zwischen 17:00 und 23:30: eine **vor Schultagen** (Sonntag bis Donnerstag) und eine für **Freitag und Samstag**.
- Ab dieser Uhrzeit bis 6 Uhr morgens lässt sich nicht spielen. Ein laufendes Spiel bekommt vorher Hinweise und wird dann beendet, genau wie beim Zeitlimit.
- Gelten Zeitlimit und Schlafenszeit gleichzeitig, zählt die Grenze, die früher erreicht ist. Oben steht dann z. B. „bis 20:00“ oder „noch 25 Min.“.
- „+15 Min.“ verlängert bei erreichter Schlafenszeit den Abend („länger aufbleiben“) statt der Tageszeit.

**Spiele pro Profil freigeben** (Spielzeit-Fenster → „Spiele: Auswählen …“):
- Ganze Konsolen freigeben (dann zählen auch Spiele, die später dazukommen) oder einzelne Spiele ankreuzen; mit Suchfeld.
- Alles andere ist in diesem Profil unsichtbar, auch unter „Zuletzt gespielt“ und „Favoriten“, und lässt sich nicht starten.
- „Emulator ohne Spiel öffnen“ ist in so einem Profil gesperrt.
- „Alle Spiele erlauben“ hebt die Auswahl wieder auf.

**Geschützte Profile:** Sobald ein Profil ein Limit hat, brauchen alle Profile **ohne** Limit die PIN, zum Beispiel deins.
- Wer zu einem anderen Profil wechselt, ist abgemeldet. Zurück geht es nur wieder mit der PIN.
- Startet RetroDaD in einem geschützten Profil, fragt er zuerst „Wer spielt?“.
- Neue Profile anlegen und Profile entfernen geht ebenfalls nur mit der PIN.
- Nach 5 falschen Eingaben ist die PIN-Eingabe für 1 Minute gesperrt; jeder weitere Fehlversuch verdoppelt die Wartezeit, bis höchstens 15 Minuten.

**PIN vergessen:** Im PIN-Feld auf „PIN vergessen?“ tippen.
- RetroDaD schickt einen **6-stelligen Code** an die hinterlegte Adresse. Er gilt 15 Minuten; danach wählst du eine neue PIN.
- Ohne Mailversand geht es mit dem **Notfall-Code**. Der gilt nur einmal, danach zeigt RetroDaD einen neuen an.
- Die PIN selbst wird nie verschickt, weil sie nirgends im Klartext gespeichert ist.

**Mailversand einrichten:** Spielzeit-Fenster → Mailversand → Einrichten.
- Als **Absender** brauchst du ein Postfach, das den Versand aus Programmen erlaubt: GMX, WEB.DE, Gmail, iCloud, T-Online oder ein eigener Server.
  - GMX und WEB.DE: in den Postfach-Einstellungen „POP3/IMAP Abruf“ den Versand über externe Programme erlauben.
  - Gmail und iCloud: ein App-Passwort anlegen und das statt des normalen Passworts eintragen.
- **Outlook/Hotmail** geht als Absender nicht, weil Microsoft das für Programme abgeschaltet hat. Als **Empfänger** funktioniert es.
- Das Passwort wird mit Windows (DPAPI) verschlüsselt und kann nur unter deinem Windows-Konto gelesen werden.
- „Testmail“ prüft, ob alles klappt.

**Grenzen:** Der Schutz ist für den Alltag gedacht, nicht gegen jemanden, der am PC Dateien bearbeitet. Wer Folgendes kann, kommt um das Limit herum:
- die Emulatoren direkt aus dem Ordner starten
- `bin\jsons\zustand.json` löschen
- die Windows-Uhr vorstellen (Zurückstellen bringt keine neue Zeit)

Dagegen hilft ein eigenes Windows-Konto ohne Administratorrechte für die Kinder.
Beim ersten Spiel mit Limit kann Windows für RetroArch nach einer Firewall-Freigabe fragen. „Abbrechen“ reicht, die Hinweise kommen trotzdem an.

## RetroDaD-Erfolge
Orden oben rechts oder Taste **E**. Zusätzlich zu RetroAchievements gibt es **47 eigene Erfolge pro Profil** plus Stufen-Erfolge. Beispiele:
- das erste reparierte Spiel, 5 reparierte Spiele
- **Sammler-Stufen** je Konsole: Bronze 10, Silber 25, Gold 50, Platin 100 Spiele
- **Mathe-Profi** (Stufen): Bronze 100, Silber 500, Gold 1000, Platin 5000 gelöste Mathe-Aufgaben (zählt, was mit höchstens einer Tippkarte gelöst wurde)
- neu in 3.10: „Gesucht & gefunden“ (zehnmal ein Spiel über die Suche gestartet), „Indie-Liebhaber“ (1 Spiel aus dem Homebrew-Store, früher „Homebrew-Held“), „Retro-Freak“ (50 Spiele aus dem Homebrew-Store)
- „Bis zur letzten Sekunde“ (Eltern-Limit ausgereizt), „Rechtzeitig Schluss“ (nach der Warnung selbst aufgehört)
- „Licht aus!“ (Dunkelmodus), „Uuh, Geisterstunde!“ (nach Mitternacht gespielt), „Zeitreise“, „Treue Seele“ und einige geheime
- neu in 3.9: „Stromsparer“, „Volle Power“, „Analyst“, „Datenfuchs“, „Familienchronist“, „Jedem das Seine“, „Maß halten“ (7 Tage am Stück, nie über eine Stunde) und vier geheime

Neue Erfolge erscheinen oben als kleine Meldung, sobald du wieder in RetroDaD bist.
**Bilder:** Alle 52 Abzeichen liegen in `bin\ui\erfolge\` (256 × 256 px). Eigene Bilder mit gleichem Dateinamen ersetzen sie einfach. Die Dateinamen und passende Bildbeschreibungen für ChatGPT stehen in `bin\ui\erfolge\ERFOLGE-BILDER.md`. Fehlt ein Bild, zeigt RetroDaD eine Münze mit Symbol.

## Controller zuweisen (Spieler 1–4)
Menü → „Controller zuweisen“: Platz wählen und auf dem gewünschten Controller **A** drücken.
Die Zuordnung gilt für die RetroArch-Konsolen und bleibt auch nach dem Umstecken erhalten, weil RetroDaD die Controller am Namen wiedererkennt.
Plätze ohne Zuweisung vergibt RetroArch automatisch.

## Cover und Titel
- Cover kommen automatisch aus der freien Datenbank *libretro-thumbnails*. Am besten klappt das mit Dateinamen wie `Super Mario World (Europe).sfc`.
- Über Rechtsklick kannst du **Cover hinzufügen/ersetzen** (Bild wählen), **Cover im Web suchen** und den **Titel ändern**.
- Eigene Cover gehen immer vor. Gespeichert werden sie in `bin\covers\_eigene`, die Titel in `bin\jsons\anpassungen.json`.

## Steuerung
Menü → **Steuerung anpassen** (oder **S**): Zeichnung des Konsolen-Controllers und Liste aller Tasten.
Taste wählen, Enter drücken, neue Taste drücken. **←/→** wechselt zwischen Tastatur und Controller, **Entf** leert eine Taste.
- **RetroArch-Konsolen**: Die Belegung wird beim Spielstart automatisch übernommen. Beim Pro Controller schaltet RetroDaD auf SDL2 um.
- **PCSX2 / Dolphin**: Die Belegung wird als Profil „RetroDaD“ gespeichert. „In … übernehmen“ macht sie zum Standard, die alten Einstellungen werden vorher als `.launcher-sicherung` gesichert.
- **Übrige Emulatoren**: „Im Emulator einstellen“ öffnet deren eigene Einstellungen.

## Homebrew-Store
Rosa Tasche oben rechts oder Taste **H**. Drei Quellen für freie Homebrew-Spiele (wechseln mit **Q** bzw. ZL/ZR, Konsole mit Tab bzw. L/R):
- **Homebrew Hub** (hh.gbdev.io): Game Boy, Game Boy Color, GBA, NES. ROM-Hacks sind ausgeblendet.
- **PDRoms** (pdroms.de): Game Boy, GBA, NES, SNES, Mega Drive, N64, DS – nur Spiele, keine Demos. Die Suche schaut jeweils einige Seiten durch.
- **itch.io**: kostenlose Spiele mit dem passenden Stichwort. Hier wird auf der Seite der Entwickler heruntergeladen (oft „Zahl, was du willst“): RetroDaD öffnet die Seite im Browser und übernimmt die Spieldatei danach **20 Minuten lang von selbst aus deinem Download-Ordner** – auch aus ZIP-Dateien. Die Datei im Download-Ordner bleibt liegen. Manche Einträge sind nur im Browser spielbar und haben gar keine Spieldatei.

„Laden“ legt das Spiel in `Spiele\<Konsole>\Homebrew` ab, und es erscheint sofort (bei Homebrew Hub und PDRoms mit Bild).
Kommerzielle Spiele gibt es hier nicht. Die legst du als Dumps deiner eigenen Module und Discs selbst ab.

## RetroAchievements (Erfolge)
1. Kostenloses Konto auf **retroachievements.org** anlegen. Dort unter Einstellungen → Schlüssel den **Web-API-Key** kopieren.
2. In RetroDaD unter Einstellungen → Allgemein → **RetroAchievements → Verbinden …** Benutzernamen und Web-API-Key eintragen.
   Ein Passwort speichert RetroDaD nicht.
3. In RetroArch einmal unter Einstellungen → Erfolge anmelden. RetroDaD schaltet die Erfolge dann bei jedem Spielstart ein.

Der Fortschritt erscheint als Pokal-Abzeichen auf den Kacheln, z. B. „30 %“, und in den Spieldetails, z. B. „12 von 40 · gemeistert“.
Nach jedem Spiel wird er aufgefrischt.

## Emulator-Updates
Einmal täglich prüft RetroDaD, ob es neuere Versionen der Emulatoren gibt, die der Installer geladen hat.
Gibt es welche, erscheinen ein roter Punkt am Einstellungen-Knopf und ein Hinweis. Unter Einstellungen → **Emulator-Updates → Jetzt aktualisieren**
werden nur die betroffenen Emulatoren aktualisiert.

## Aufräumen
Menü → **Aufräumen** (grauer Besen). Gelöscht wird hier nichts: Originale landen immer in `Spiele\_Aussortiert\<Konsole>`.
Von dort kannst du sie zurückholen oder selbst löschen, wenn alles läuft.
- **Doppelte Spiele**: RetroDaD findet Spiele mit gleichem Titel innerhalb einer Konsole, z. B. zwei Regionen desselben Spiels,
  und identische Dateien. Markieren und „beiseitelegen“. Von jeder Gruppe muss mindestens eine Datei bleiben.
- **Platz sparen**: verlustfreies Umwandeln großer Disc-Abbilder:
  PS1 (.cue/.bin) und PS2 (.iso) werden zu **CHD**, GameCube und Wii (.iso/.gcz/.wbfs) zu **RVZ**. Das spart meist 40–60 %.
  Für PlayStation wird `chdman` aus dem offiziellen MAME-Paket gebraucht, der Knopf „chdman installieren“ lädt es.
  Für GameCube und Wii nutzt RetroDaD das DolphinTool, das bei Dolphin dabei ist.
  Die Umwandlung läuft im Hintergrund mit Fortschrittsbalken. Jede neue Datei wird geprüft, bevor das Original beiseitegelegt wird.

## Switch 2 mit Lichii (experimentell)
- Lichii ist ein sehr frischer, experimenteller Switch-2-Emulator (Weiterentwicklung von Eden). Viele Spiele starten gar nicht oder ruckeln; Abstürze sind normal.
- Menü → „Emulatoren installieren“ lädt die neueste Lichii-Version von GitHub (zortos293/Lichii) nach `bin\Emulatoren\Lichii`.
- Switch-2-Spiele erkennt RetroDaD an der Programm-ID (`0400…` im Dateinamen oder im entpackten Spiel) – sie erscheinen dann unter „Switch 2 · Lichii“, auch wenn sie im Ordner `Spiele\Switch` liegen. Alles im Ordner `Spiele\Switch2` gilt ebenfalls als Switch-2-Spiel.
- Schlüssel und Firmware: siehe nächster Abschnitt. Liegen eigene Dateien deiner Switch 2 im Unterordner `bin\Switch-Dateien\Switch2`, bekommt Lichii diese, sonst dieselben wie Eden. RetroDaD spielt sie beim nächsten Start von selbst ein – auch wenn nur der Unterordner `Switch2` gefüllt ist. Nach einem Update deiner Switch 2 legst du einfach die neuen Dateien dorthin.

## Switch: Updates und DLC
Update- und DLC-Dateien (`.nsp`) einfach mit in `Spiele\Switch` legen – gern in einen Unterordner wie `Spiele\Switch\Updates`. Am besten steht die **Title-ID** im Dateinamen (16 Zeichen in eckigen Klammern, z. B. `[0100000000010800]`). Fehlt sie, liest RetroDaD sie aus der NSP selbst (aus dem Ticket im Inhaltsverzeichnis) – das klappt bei fast allen Updates und DLCs. Nur wenn auch das nicht geht, erscheint die Datei als eigene Kachel; dann die ID in den Dateinamen schreiben.

- RetroDaD erkennt an der ID, was es ist: Grundspiel endet auf `…000`, Update auf `…800`, DLC liegt im Block danach (`…1001`, `…1002` …). Updates und DLC bekommen **keine eigene Kachel** mehr, sondern erscheinen am Spiel als „+ Update Nr. 3 · 2 DLC“ (bei mehreren Updates z. B. „2 Updates (neuestes Nr. 3)“ – Eden nimmt automatisch das neueste).
- Beim Start trägt RetroDaD ihren Ordner in Eden bzw. Lichii unter **External Content** ein (ab Eden 0.2). Eden lädt sie dann direkt – nichts wird kopiert oder installiert, deine eigenen Einträge dort bleiben erhalten.
- Ältere Eden-Version oder fehlt das Update im Spiel trotzdem? Spiel → Details → **Updates & DLC … → In Eden installieren**: Eden öffnet sich mit dem Ordner, dort *Datei → Install Files to NAND …* wählen.
- Liegen Updates ohne passendes Grundspiel herum, meldet das die Diagnose.

## Switch einrichten (Schlüssel und Firmware)
Eden braucht für Switch-Spiele die Schlüssel (`prod.keys`) und die Firmware **deiner eigenen Switch**. RetroDaD liefert sie nicht mit und lädt sie nicht herunter, spielt sie aber selbst in Eden ein:
- **Automatisch:** `prod.keys` (optional `title.keys`) und die Firmware als ZIP in den Ordner `bin\Switch-Dateien` legen. Beim nächsten Start von RetroDaD werden sie eingespielt; eine Meldung bestätigt das.
- **Von Hand:** Einstellungen → Konsolen → Switch → „Schlüssel wählen …“ bzw. „Firmware-ZIP wählen …“. Dort steht auch, ob Schlüssel und Firmware schon da sind.
- Schon vorhandene Dateien in Eden werden nicht gelöscht: eine alte `prod.keys` wird zu `prod.keys.launcher-sicherung-…`, eine alte Firmware zum Ordner `registered.alt-…`.
- Eden muss dafür geschlossen sein. Fehlt noch etwas, sagt RetroDaD beim Start eines Switch-Spiels Bescheid.
- Schlüssel und Firmware sollten aus demselben Stand der Switch stammen, sonst starten manche Spiele nicht.
- Die Dateien niemals weitergeben.

## Fehlende RetroArch-Kerne
Jede RetroArch-Konsole braucht ihren „Kern“ (z. B. `mgba` für den GBA, `melondsds` für den DS) im Ordner `bin\Emulatoren\RetroArch\cores`.
- Fehlt einer, lädt RetroDaD ihn beim Start selbst nach (für alle Konsolen, in denen Spiele liegen) – von buildbot.libretro.com, der offiziellen RetroArch-Quelle.
- Startest du ein Spiel, dessen Kern fehlt, wird er sofort geladen und das Spiel danach gestartet.

## Hinweise vor dem Spielstart
Vor jedem Start zeigt RetroDaD ein paar Sekunden lang:
- wie man das Spiel beendet (Controller-Kombination bzw. Esc)
- ob automatisch gespeichert wird
- wie viel Spielzeit bzw. Zeit bis zur Schlafenszeit noch bleibt

Enter / A startet sofort, Esc / B bricht ab. Abschalten: Einstellungen → Allgemein → „Hinweise vor dem Spielstart“.

## Röhrenfernseher-Look
Einstellungen → Konsolen.
- Bei jeder Konsole, die über RetroArch läuft, gibt es den Schalter „Bild: Röhrenfernseher-Look“, ganz oben auch „Für alle an/aus“.
- NES, SNES, N64, Mega Drive und PS1 bekommen Scanlines wie am alten Fernseher; Game Boy, GBA und DS ein feines LCD-Raster.
- Die Filter kommen von RetroArch. Menü → „Emulatoren installieren“ lädt sie nach, falls sie fehlen.
- Für PS2, GameCube/Wii, Switch, PS3, PS4 und Xbox gibt es den Schalter nicht. Diese Spiele sind für flache Bildschirme gemacht bzw. die Emulatoren haben eigene Grafikfilter in ihren Einstellungen.

## Hintergrundmusik
- Eigene Musikdateien in den Ordner `Musik` legen (Unterordner sind erlaubt).
- Einschalten unter Einstellungen → Allgemein → Hintergrundmusik, dort auch leiser/lauter.
- Die Titel laufen in zufälliger Reihenfolge, beim Spielstart wird ausgeblendet, danach geht es weiter.

## Spielstände sichern
Einstellungen → Allgemein → „Spielstände sichern“.
- Einmal am Tag (beim Start von RetroDaD) wird eine ZIP-Datei `RetroDaD-Sicherung_Datum_Uhrzeit.zip` angelegt – nur wenn sich seit der letzten Sicherung etwas geändert hat.
- Standardordner ist `OneDrive\RetroDaD-Sicherungen` (ohne OneDrive: `Dokumente\RetroDaD-Sicherungen`); ändern mit „Ändern …“.
- Es bleiben die letzten 10 Sicherungen (einstellbar: 3 bis 30). Ältere **eigene** Sicherungs-ZIPs werden ersetzt, andere Dateien im Ordner fasst RetroDaD nicht an.
- Gesichert werden die gefundenen Spielstand-Ordner von RetroArch, Dolphin, PCSX2, Eden, RPCS3, shadPS4 und Xenia sowie die Profile und Einstellungen von RetroDaD. Die Festplatte von xemu (Xbox) ist zu groß und bleibt außen vor.
- **Zurückholen:** Sicherung öffnen und den gewünschten Ordner an seinen Platz kopieren, während RetroDaD und die Emulatoren geschlossen sind. Die Ordnernamen im ZIP entsprechen den Emulator-Ordnern.

## Schneller und robuster (3.13)
- **Schnellstart:** RetroDaD zeigt beim Start sofort die Spieleliste vom letzten Mal und liest im Hintergrund neu ein. Hat sich etwas geändert (neue Spiele, neue Cover), aktualisiert sich die Liste von selbst – die Auswahl bleibt stehen.
- **Kleinere Cover:** Mit dem Python-Paket *Pillow* werden Cover auf Kachelgröße verkleinert (statt bis zu 900 KB nur noch ~60 KB) – vorhandene einmal im Hintergrund. Das Blättern geht flüssiger. `start.bat` installiert Pillow beim ersten Start mit, sonst Einstellungen → Leistung → *Pillow installieren*. Deine eigenen Cover werden nicht verändert.
- **Prüfung vor dem Start:** Leere, abgebrochene oder falsch benannte Spieldateien (ZIP, NSP, XCI, CHD, RVZ, ISO …), fehlende .bin zu einer .cue, fehlendes PS1-BIOS (RetroArch-Ordner `system`) oder fehlende PS3-Firmware fallen vor dem Start auf – mit Knopf zur Lösung. Fehlt das PS2-BIOS oder sind die xemu-Dateien nicht eingetragen, gibt es einen Hinweis.
- **Absturz-Hilfe:** Schließt sich ein Emulator in den ersten Sekunden wieder, liest RetroDaD seine Protokolle und sagt, woran es vermutlich liegt – mit passendem Knopf: *Grafik auf OpenGL umstellen* (Vulkan-Probleme bei Eden, Lichii, Dolphin, PCSX2), *Visual C++ Laufzeit laden* (fehlende Windows-DLL, offizieller Microsoft-Download), *Ordner für Schlüssel & Firmware*, *BIOS-Ordner* oder *Leistungs-Einstellungen* (zu wenig Arbeitsspeicher).
- **Einheitlicher Ladebildschirm:** Beim Spielstart bleibt der RetroDaD-Ladebildschirm über dem Emulator, bis das Spiel wirklich startet – statt der unterschiedlichen Ladebildschirme der Emulatoren. Dabei wechseln Tipps: zu deinem Spiel (Spielzeit, zuletzt gespielt, RetroAchievements, Updates/DLC), zu den Tasten des Emulators und zu RetroDaD. Ein Klick darauf geht direkt zum Spiel. Abschaltbar unter Einstellungen → Allgemein.

## Spiele laufen besser (3.14/3.15)
Alles unter Einstellungen → **Leistung**; vor dem Start nennt RetroDaD außerdem Bremsen, die sich schnell beheben lassen.
- **Grafiktreiber-Check:** zeigt Datum und Alter deines Grafiktreibers. Ist er älter als ein Jahr, gibt es einmal im Monat einen Hinweis und den Knopf *Neuen Treiber holen* (offizielle Seite von NVIDIA, AMD bzw. Intel). Gerade für Switch und PS3 bringt ein aktueller Treiber oft mehr als jede Einstellung.
- **Strom:** Läuft der Laptop auf Akku oder ist der Windows-Energiesparmodus an, sagt RetroDaD das vor dem Start – beides bremst CPU und Grafik stark.
- **Hintergrundlast:** Ist kaum noch Arbeitsspeicher frei oder rechnet ein Programm gerade viel, nennt RetroDaD es vor dem Start („Chrome belegt 3,1 GB – schließen hilft“). Geschlossen wird nichts.
- **Xbox-Hintergrundaufnahme:** Nimmt Windows ständig die letzten Minuten auf, zeigt RetroDaD das mit *Öffnen …* – ausschalten tust du es selbst.
- **Leistungskerne bevorzugen:** Bei CPUs mit schnellen und sparsamen Kernen (Intel ab 12. Generation) laufen Emulatoren bevorzugt auf den schnellen Kernen – nur der Emulator, nicht Windows insgesamt.
- **Switch bei wenig Grafikspeicher (bis 6 GB):** Eden und Lichii legen Texturen komprimiert ab (ASTC → BC3), gehen sparsam mit dem Grafikspeicher um und spielen Videos auf der Grafikkarte ab – gegen Ruckler und Abstürze in Zwischensequenzen.
- **Shader-Cache – ein Knopf, je nach Grafikkarte:** RetroDaD erkennt beim Start, welche Grafikkarte die Spiele rechnet, und stellt den Knopf passend um:
  - *NVIDIA:* Größe auf **unbegrenzt** stellen (wie bisher, mit Windows-Rückfrage).
  - *AMD Radeon:* Die Größe legt AMD fest. **Shader-Cache leeren** (über AMDs offizielle Treiber-Schnittstelle ADLX, wie der Knopf in Adrenalin) hilft, wenn nach einem Treiber- oder Emulator-Update plötzlich Ruckler, Abstürze oder Grafikfehler auftreten – schneller wird sonst nichts. Erst nach Rückfrage, nie automatisch. Steigt der Treiber mitten im Spiel aus („device lost“), schlägt die Absturz-Hilfe das Leeren von selbst vor.
  - *Intel:* verwaltet den Cache selbst, es gibt nichts einzustellen.
- **Resizable BAR (Intel Arc) / Smart Access Memory (AMD):** RetroDaD prüft, ob der Prozessor den ganzen Grafikspeicher sieht oder nur 256 MB. Bei Arc-Karten ist das der größte Hebel überhaupt. Ist es aus, zeigt *So schaltest du es ein …* die Schritte im BIOS (Above 4G Decoding an, Re-Size BAR an, CSM aus). Umstellen kannst nur du – RetroDaD ändert nichts am BIOS.

## Bewegter Ladebildschirm sichtbarer (3.32)
- Die Blöcke starten jetzt immer im sichtbaren Bild (vorher liefen sie oft außerhalb), es sind mehr und kleinere, und wer aus dem Bild läuft, taucht woanders wieder auf. Im dunklen Design waren sie fast unsichtbar (stark abgedunkelt und weichgezeichnet) – jetzt kräftiger und schärfer.
- Ist die Animation gerade abgeschaltet (Akkubetrieb, Windows-Energiesparmodus, Leistung „Sparsam“, leichte Oberfläche), steht der Grund klein unter dem Ladebildschirm.

## Mitteilungen löschen (3.30, Fehler behoben in 3.31)
- In den Mitteilungen hat jede Nachricht ein kleines **×** (erscheint beim Drüberfahren mit der Maus) – damit löschst du sie einzeln. Oben gibt es **Alle löschen** (mit Rückfrage). In 3.30 schloss sich die Rückfrage sofort wieder und die Ansicht blieb stehen – das ist behoben.
- Mit dem Controller: hoch/runter wählt eine Mitteilung, X/Y löscht sie, Menü-Taste löscht alle.

## Chat mit Freunden (3.29)
- In der Freundesliste einen Freund antippen → **Chat**. Die Nachrichten stehen wie bei WhatsApp untereinander: deine rechts in Grün, seine links, nach Tagen getrennt, mit Uhrzeit. Mit Tastatur schreiben und Enter drücken – mit dem Controller öffnet A ein Eingabefeld.
- Neue Nachrichten holt RetroDaD alle 90 Sekunden (im offenen Chat alle 30 Sekunden). Kommt etwas an, erscheint „💬 Anna: …“ als Hinweis und in den Mitteilungen; in der Freundesliste steht „💬 2 neu“.
- **Nur ihr beide könnt lesen:** Jede Nachricht ist mit einem Schlüssel verschlüsselt, den nur eure zwei PCs ausrechnen können (Schlüsselaustausch nach Diffie-Hellman). Auf den Relais sieht niemand den Inhalt und auch nicht, wer mit wem schreibt. Nachrichten von jemand anderem als deinem eingetragenen Freund werden verworfen. Schreiben geht, sobald dein Freund einmal mit 3.29 online war.
- **Kinderprofile (mit Eltern-PIN):** Der Chat ist dort zuerst aus. Die Eltern erlauben ihn unter Freunde → *Chat* mit der PIN. Gespeichert werden die Nachrichten nur auf eurem PC (`bin\jsons\chats.json`, die letzten 500 je Freund).

## Freunde – wer ist online? (3.28)
- Profil anklicken (P) → **Freunde**. Jedes Profil hat einen eigenen **Freundescode** (z. B. `RD-7K4M-Q2XP-9TB3`) – ohne Konto, ohne E-Mail, ohne Passwort. Gib ihn deinen Freunden; trage ihre Codes unter *Freund hinzufügen* ein.
- In der Liste siehst du grün „online · spielt Mario Kart 8 Deluxe · Nintendo Switch“ oder grau „zuletzt vor 2 Std.“. Der Status kommt mit einigen Minuten Verzögerung; RetroDaD meldet sich alle 4 Minuten und beim Start und Ende eines Spiels.
- Technik: Das läuft über **Nostr**, ein offenes Netz aus vielen kostenlosen Relais (RetroDaD nutzt mehrere gleichzeitig) – es braucht keinen eigenen Server. Der Status ist verschlüsselt; lesen kann ihn nur, wer deinen Freundescode hat. Beim ersten Kontakt merkt sich RetroDaD den Schlüssel deines Freundes, damit sich später niemand als er ausgeben kann. Es gibt keine Suche nach Fremden, und niemand kann dich ohne deinen Code finden.
- Jugendschutz: In Kinderprofilen (mit Eltern-PIN) gehen Freunde hinzufügen, entfernen und das Ein-/Ausschalten des Online-Status nur mit PIN. Unter *Online-Status* kann jedes Profil unsichtbar werden.
- Beide brauchen RetroDaD 3.28 oder neuer. Chat-Nachrichten kommen als nächster Schritt.

## Mitteilungen zum Nachlesen (3.27)
- Alles, was RetroDaD dir einblendet und was du später noch brauchst – Hinweise beim Start, Updates, „Übernommen: Switch, PS2-BIOS“, fertiges Umwandeln/Kopieren, Einspielen von Schlüsseln und Firmware, Warnungen – landet jetzt in den **Mitteilungen**: Profil anklicken (P) → *Mitteilungen*.
- Sie stehen wie in einem Chat untereinander: nach Tagen getrennt („Heute“, „Gestern“ …), mit Uhrzeit, Warnungen mit farbigem Rand. Was seit deinem letzten Blick dazugekommen ist, steht unter „Neu“; am Profilbild zeigt ein roter Punkt die Zahl der neuen Mitteilungen – je Profil.
- Gleiche Meldungen innerhalb einer halben Stunde stehen nur einmal drin; aufgehoben werden die letzten 300.

## Abgeschnittene Switch-Spiele erkennen (3.26)
- Vor dem Start liest RetroDaD bei NSP/NSZ das Inhaltsverzeichnis und bei XCI/XCZ den Kopf der Datei: Darin steht, wie groß sie sein muss. Fehlt etwas am Ende (Kopieren oder Herunterladen abgebrochen), sagt RetroDaD das statt den Emulator stumm scheitern zu lassen – z. B. „6,4 GB von 7,1 GB sind da“.

## Ein Import-Ordner für alle Konsolen (3.25)
- Aus `bin\Switch-Dateien` wird **`bin\Import`** mit einem Ordner je Konsole, die etwas von deiner eigenen Konsole braucht: `Switch`, `Switch2`, `PS1`, `PS2`, `PS3`, `PS4`, `Xbox`. In jedem liegt eine `HIER_ABLEGEN.txt`, die sagt, was hinein gehört; `Import\LIESMICH.txt` hat die Übersicht.
- Beim ersten Start zieht RetroDaD den alten Ordner um: Schlüssel und Firmware wandern nach `Import\Switch`, der Unterordner `Switch2` nach `Import\Switch2`. Übrig gebliebene alte Anleitungen landen unverändert in `bin\Updates\alt-Switch-Dateien-…` – gelöscht wird nichts.
- Was im Import-Ordner liegt, bleibt dort; RetroDaD kopiert es an den Platz, den der Emulator erwartet: PS1-BIOS → RetroArch `system`, PS2-BIOS → PCSX2 `bios`, `PS3UPDAT.PUP` → RPCS3 (installiert einmal), PS4-`sys_modules` → shadPS4, Xbox-MCPX/BIOS/Festplatte → `xemu\bios` und in `xemu.toml` eingetragen (vorhandene gültige Einträge bleiben, die alte Datei wird gesichert). Das passiert beim Start und vor jedem PlayStation- bzw. Xbox-Spiel – einfach Datei hineinlegen und das Spiel noch einmal starten.
- Dein OneDrive-Ordner wird jetzt in diesen Import-Ordner abgeglichen. Hinweise vor dem Start („BIOS fehlt“, „Firmware fehlt“) öffnen direkt den passenden Import-Ordner. Einstellungen → *Import-Ordner* öffnet ihn ebenfalls.

## Schlüssel und Firmware passen zusammen (3.24)
- **prod.keys älter als die Firmware:** Ab Firmware 17 braucht Firmware *N* Schlüssel bis Generation *N*. Sind die `prod.keys` älter (z. B. Schlüssel bis 22.x, Firmware 23.5.0), kann Eden/Lichii die Firmware nicht entschlüsseln – es nimmt dann eine eingebaute Ersatz-Version, und z. B. die Mii-Auswahl in Mario Kart 8 Deluxe bleibt leer. RetroDaD spielt eine solche Firmware jetzt **nicht** mehr ein (die bisherige bleibt) und sagt, was fehlt: Schlüssel neu von deiner Konsole sichern – auf demselben Stand wie die Firmware.
- Vor dem Start eines Switch-Spiels schaut RetroDaD ins letzte Eden-Protokoll; steht dort, dass die Firmware nicht lesbar war, kommt derselbe Hinweis.

## Mehr Homebrew, Firmware-Hinweis (3.23)
- **Drei neue Quellen im Homebrew-Store** (oben bei den Quellen, mit ZL/ZR wechseln):
  - **DS** – freie DS-Spiele aus *Universal-DB* (Data from Universal-DB, db.universal-team.net).
  - **Wii** – freie Wii-Spiele aus dem *Open Shop Channel* (oscwii.org). Der ganze App-Ordner kommt nach `Spiele\Wii\Homebrew\<Spiel>`, die Startdatei heißt wie das Spiel; Dolphin startet sie direkt (`.dol`/`.elf` werden jetzt erkannt).
  - **Switch** – freie Switch-Spiele aus dem *Homebrew App Store* (fortheusers.org). Die Spieldaten landen auf Edens SD-Karte (`sdmc`), die `.nro` zusätzlich in `Spiele\Switch\Homebrew`, damit das Spiel in der Bibliothek steht.
  Gezeigt werden nur Spiele – keine Werkzeuge, Emulatoren oder Exploits und keine Umsetzungen, die die Dateien eines gekauften Spiels brauchen (z. B. DevilutionX).
- **Switch-Firmware fehlt:** Ist in Eden keine Firmware installiert, sagt RetroDaD das jetzt vor dem Start. Ohne Firmware bleibt z. B. Mario Kart 8 Deluxe bei „Select a Mii“ mit leeren Kästchen hängen.

## OneDrive, Controller-Akku, Heimnetz (3.22)
- **Konsolen-Dateien aus OneDrive:** Einstellungen → *Konsolen-Dateien aus OneDrive*. Lege dort einen Ordner mit Schlüsseln, Firmware und BIOS **deiner eigenen Konsolen** an – RetroDaD findet ihn beim ersten Start von selbst (sucht im OneDrive nach `prod.keys`, einer Firmware-ZIP, `PS3UPDAT.PUP` oder `scph…bin`) oder du wählst ihn aus. Bei jedem Start kommt Neues an den richtigen Platz:
  - Switch: `prod.keys`, `title.keys`, Firmware-ZIP/-Ordner → `bin\Switch-Dateien` (Unterordner `Switch2` → `Switch-Dateien\Switch2`); RetroDaD spielt sie danach wie gewohnt in Eden/Lichii ein.
  - PS1: BIOS (z. B. `scph5501.bin`) → RetroArch `system`.
  - PS2: BIOS (4-MB-Dateien oder alles im Unterordner `PS2`) → PCSX2 `bios`.
  - PS3: `PS3UPDAT.PUP` → RPCS3; RetroDaD startet die Installation (`rpcs3 --installfw`) – nur wenn noch keine Firmware da ist oder die Datei neu ist. Im RPCS3-Fenster bestätigen.
  - PS4: Ordner `sys_modules` → shadPS4 `user\sys_modules`. PS5 (KytyPS5) braucht nichts.
  Gelesen wird nur der OneDrive-Ordner auf diesem PC (OneDrive synchronisiert ihn mit deinem Konto) – RetroDaD lädt nichts über Freigabelinks aus dem Internet. Bitte den Ordner nicht per Link für andere freigeben. Nichts wird gelöscht, vorhandene gleiche Dateien werden nicht erneut kopiert.
- **Akkustand der Controller:** Neben dem Controller-Symbol oben rechts zeigt eine kleine Batterie je kabellosem Controller den Stand (voll/halb/schwach/leer). Wird ein Akku schwach, kommt einmal ein Hinweis – und vor dem Spielstart steht „Akku fast leer“, damit der Controller nicht mitten im Spiel ausgeht. Windows liefert dafür nur Stufen, keine Prozente.
- **Heimnetz – Spiele von einem anderen PC holen** (Menü → *Heimnetz*): Auf dem PC mit den Spielen *Diesen PC freigeben* – es erscheint ein 6-stelliger Code. Auf dem anderen PC *Spiele holen*: RetroDaD findet den PC, du gibst den Code ein (auch mit dem Controller) und siehst, welche Spiele hier noch fehlen. Kopiert wird direkt übers Heimnetz in den Spieleordner der jeweiligen Konsole, samt Updates/DLC und ganzen Spielordnern (PS3/PS4). Bricht es ab, geht es beim nächsten Mal an derselben Stelle weiter.
  - Sicher: Die Freigabe läuft nur, solange du sie anlässt (höchstens 2 Stunden), nur für Geräte im eigenen Netz, nur mit Code und nur lesend. Abgegeben werden nur Spieldateien – keine Schlüssel, Firmware, BIOS oder Spielstände. Auf dem holenden PC wird nie etwas überschrieben.
  - Beim ersten Freigeben fragt die Windows-Firewall nach Python: *Private Netzwerke* erlauben. Findet die Suche nichts, kannst du die Adresse eingeben, die der freigebende PC anzeigt.

## Spiele kleiner, Start gemessen (3.21)
- **Switch-Spiele komprimieren (NSZ/XCZ):** Unter Menü → Aufräumen → *Platz sparen* stehen jetzt auch Switch-Spiele samt ihren Updates und DLC. RetroDaD packt sie verlustfrei block-komprimiert (`.nsp` → `.nsz`, `.xci` → `.xcz`) – typisch spart das 20–40 %, bei manchen Spielen mehr. Das Werkzeug **nsz** (frei, MIT-Lizenz) installiert der Knopf *nsz installieren* nur für deinen Windows-Benutzer.
- **Nur, wenn Eden es lesen kann:** NSZ kann Eden erst seit Ende Oktober 2026. RetroDaD schaut in die Eden-Exe; ist sie älter (z. B. v0.2.1), bleiben die Switch-Spiele ausgegraut mit dem Hinweis „Eden zu alt“ – erst Eden aktualisieren. Startest du ein `.nsz` mit einer zu alten Eden, sagt RetroDaD das vorher und bietet *Eden aktualisieren* an.
- Gebraucht werden die `prod.keys` deiner eigenen Konsole in Eden (wie zum Spielen). Jede fertige Datei prüft nsz gleich nach dem Packen; ist sie nicht in Ordnung, wird nur die neue Datei verworfen. Die Originale landen in `Spiele\_Aussortiert\switch` – nichts wird gelöscht. Erst wenn das Spiel samt Update in Eden läuft, kannst du sie selbst wegräumen. Falls ein komprimiertes Update in Eden nicht greift: Original aus `_Aussortiert` zurücklegen.
- **Übersicht:** Oben bei *Platz sparen* steht, wie viel insgesamt frei werden könnte – je Konsole (PS1/PS2 → CHD, Wii/GameCube → RVZ, Switch → NSZ/XCZ). Der Selbsttest nennt die Zahl ebenfalls.
- **Startzeit im Selbsttest:** RetroDaD misst bei jedem Start, wann das Programm geladen, das Fenster da und die Spieleliste zu sehen war, wie lange das Durchsuchen der Spieleordner im Hintergrund dauerte und wie lange fehlende Cover brauchten – mit dem Schnitt der letzten zehn Starts.

## Feinschliff (3.20)
- **RetroArch-Protokoll:** Bei jedem Start einer RetroArch-Konsole schreibt RetroArch sein Protokoll nach `bin\logs\<konsole>-retroarch.log`. Die Absturz-Hilfe liest es mit, und der Selbsttest zeigt unter „Controller“, welchen Controller RetroArch beim letzten Start an welchem Platz erkannt hat – oder dass es keinen gefunden hat.
- **Saubere Spielnamen:** Versionsangaben („v1.3.0“), Webadressen und Kennungen im Dateinamen verschwinden; „Turtles_ Splintered Fate“ wird zu „Turtles: Splintered Fate“ (Windows erlaubt keinen Doppelpunkt in Dateinamen). Schon geladene Cover werden weiter unter dem alten Namen gefunden.
- **Ehrlicherer Selbsttest:** Ein alter Treiber zählt nur noch bei der Grafikkarte, auf der die Emulatoren laufen – die Onboard-Grafik eines Laptops wird nur noch zur Info genannt, auch beim Hinweis vor dem Start. „GPU-Planung“ zeigt „Windows-Standard“, wenn sie nie von Hand umgestellt wurde, statt „unbekannt“.
- **Spielstand-Sicherung:** täglich oder wöchentlich wählbar; sie läuft jetzt auch nach dem Spielen (nie während ein Spiel läuft), nicht nur beim Start von RetroDaD. Liegt das Ziel auf demselben Laufwerk wie die Spielstände, warnt RetroDaD. Ist die Sicherung aus, erinnert RetroDaD höchstens einmal im Monat daran.

## Neuer Ladebildschirm (3.19)
- Beim Spielstart: weichgezeichneter bunter Hintergrund, eine kleine Kachel mit dem Spiel (ohne Cover mit den Anfangsbuchstaben) und darunter die Tipps. Die Starthinweise verschwinden, sobald geladen wird; der Shader-Hinweis bei Switch, PS3–PS5, Wii und Xbox 360 ist jetzt der erste Tipp.
- **Bewegter Ladebildschirm** (Einstellungen, standardmäßig aus): Die Blöcke wandern wie bei Snake. RetroDaD prüft bei jedem Start neu und zeigt bei Leistung „Sparsam“, leichter Oberfläche, im Akkubetrieb und im Windows-Energiesparmodus automatisch das ruhende Bild. Die Animation läuft nur, solange geladen wird – im Spiel kostet sie nichts.

## Kleinigkeiten (3.18)
- Selbsttest: Die Umlaute bei den Programmtests stimmen jetzt auch unter Windows.

## PlayStation 5 mit KytyPS5 (3.17, experimentell)
- Neue Konsole **PS5**: Spiele nach `Spiele\PS5` (ein Ordner mit `eboot.bin` je Spiel oder eine `.zar`-Datei). RetroDaD startet sie mit `kyty_emulator.exe --game …`.
- **Startoptionen (3.18):** Vollbild, Shader-Zwischenspeicher (weniger Ruckler ab dem zweiten Spielen), kein eigener Startbildschirm, Maus ausblenden, Spiele auf Deutsch und der Profilname als PS5-Benutzer. RetroDaD fragt jede KytyPS5-Version einmal mit `--help`, welche Optionen sie kennt, und gibt nur diese weiter – so starten auch ältere Fassungen und Forks. Eigene Optionen in der Konfiguration haben Vorrang.
- *Emulatoren installieren* lädt KytyPS5 von der offiziellen Release-Seite (github.com/KytyPS5/KytyPS5). Vorhandene Konfigurationen bekommen die Konsole beim nächsten Start automatisch dazu.
- KytyPS5 ist früh in der Entwicklung: Viele Spiele starten gar nicht oder nur bis zum Menü, nur wenige sind spielbar. Es braucht eine Grafikkarte mit Vulkan 1.3. Nur Spiele aus deinem eigenen Besitz verwenden.
- Spielstände von KytyPS5 sind noch nicht in der Profil-Trennung und der Sicherung – deren Ablageort steht noch nicht fest.

## Aufgeräumt und robuster (3.16)
Für dich sieht alles aus wie vorher – unter der Haube ist RetroDaD gründlich aufgeräumt:
- **Sicheres Speichern:** Profile, PIN, Spielzeiten, Erfolge, Cover und die Einstellungsdateien der Emulatoren werden erst vollständig in eine Zwischendatei geschrieben und dann in einem Schritt ausgetauscht. Ein Absturz oder Stromausfall mitten im Speichern lässt die alte Datei heil, und zwei Speichervorgänge kommen sich nicht mehr in die Quere.
- **Emulatoren einheitlich erkannt:** Eine Stelle entscheidet, ob ein Programm Eden, Lichii, RetroArch, Dolphin, PCSX2 … ist. Dadurch bekommen auch **Citron, Sudachi und andere yuzu-Nachfolger** jetzt überall dieselbe Behandlung wie Eden: Leistungs-Einstellungen, Spiel-Profile, Updates/DLC, Spielstand-Sicherung, Absturz-Hilfe und den richtigen Namen.
- **Kleine Pannen werden notiert:** Was früher still übergangen wurde (z. B. eine nicht verbuchte Spielzeit), steht jetzt in `bin\logs\retrodad.log`, und der Selbsttest zeigt es an.
- **Selbsttest robuster:** Kann ein Teil nicht geprüft werden, laufen die anderen trotzdem weiter.
- **Programm nach Themen aufgeteilt:** `bin\retrodad\` (Python) und `bin\ui\js\` (Oberfläche) statt zweier Riesendateien – Fehler lassen sich schneller finden, Neues gezielter einbauen.

## Kleine Helfer
- **Rückgängig:** Nach „Titel geändert“, „Cover ersetzt/entfernt“ und „Favorit“ steht unten einige Sekunden **Rückgängig** (oder Strg+Z).
- **Fehler mit Lösung:** Startet ein Spiel nicht, nennt RetroDaD den Grund und bietet den passenden Knopf an – z. B. *Eden jetzt installieren*, *Spiele neu einlesen*, *Laufendes Spiel beenden* oder *Emulator-Ordner öffnen*.
- **Ladebildschirm:** Beim Start zeigt RetroDaD Cover und Namen, bis das Emulator-Fenster wirklich da ist. Bei Switch, Wii, PS3/PS4/PS5 und Xbox 360 steht dabei, dass der erste Start wegen der Shader länger dauern kann. Esc bzw. Zurück blendet ihn aus.
- **Cover laden schneller:** sechs Cover gleichzeitig, die gerade sichtbare Konsole zuerst; die Namensliste einer Cover-Datenbank ist dreimal kleiner. Ist GitHub nicht erreichbar oder sind die Abfragen aufgebraucht, nimmt RetroDaD den libretro-Spiegel (thumbnails.libretro.com).
- **Hintergrund:** Er übernimmt unscharf das Cover des gewählten Spiels – Spiele ohne Cover färben ihn in ihrer Kachelfarbe.

## Einstellungen
Menü → lila Knopf. Vier Reiter: Allgemein · Leistung · Konsolen · Diagnose (◀ ▶ wechselt).
- **Konsolen ohne Spiele** sind ausgeblendet – die Liste zeigt nur, was du auch spielen kannst. Menü → Knopf „Alle Konsolen / nur mit Spielen“ (neben Hell/Dunkel) zeigt sie wieder. Solange noch gar keine Spiele da sind, erscheinen alle Konsolen.
- **Allgemein**: Vollbild, Minimieren beim Spielen, Cover laden, Konsolen ohne Emulator ausblenden, auch Konsolen ohne Spiele zeigen, dunkles Design, Cover als Hintergrund, Navigationstöne, Bildschirmschoner (nach 5 Min.), Startanimation, **Vorschau nach 5 Sekunden** (bleibst du auf einem Spiel stehen, wechselt die Kachel zwischen Titelbild und einer Spielszene – aus libretro-thumbnails, wie die Cover; Videos gibt es dort nicht)
- **Konsolen**: Konsolen ein- und ausblenden, Emulator-Programm ändern, Spieleordner hinzufügen oder entfernen, Röhrenfernseher-Look
- **Diagnose**: „Selbsttest starten“ prüft Python/pywebview, Speicherplatz, Schreibrechte, Arbeitsspeicher, Grafikkarten, Leistungsmodus, Shader-Cache (NVIDIA/AMD), Resizable BAR, Windows-Spielmodus, jeden Emulator (vorhanden? RetroArch-Kern da?), Switch-Schlüssel und Firmware, Spielstände pro Profil, Sicherung, Controller, Jugendschutz, das letzte Update und Fehlerzeilen in den Logs. Der Bericht landet als `bin\logs\diagnose-<Datum>.txt` – **ohne PIN, Passwörter, Schlüssel oder E-Mail-Adresse**, du kannst ihn also weitergeben. „Im Ordner zeigen“ und „Kopieren“ helfen dabei.
  - **Programmtests mitlaufen lassen**: Mit Haken testet RetroDaD zusätzlich sich selbst – Mathe-Aufgaben aller Klassen, Mathe-Bonus, INI-Einstellungen, Spiel-Profile, Spielstand-Wechsel, Statistik, NVIDIA-Schnittstelle, Update-Installer, Diagnose. Die Tests laufen in einer Kopie im Temp-Ordner mit eigenem, leerem Benutzerordner – deine Spiele, Spielstände und Einstellungen werden nicht angefasst. Ohne RetroDaD: `python bin\werkzeuge\tests\alle_tests.py`.
- Neue Konsolen aus Updates werden automatisch in deine `bin\jsons\config.json` übernommen.

## RetroDaD umziehen (anderer Ordner, anderer PC)
Den ganzen RetroDaD-Ordner einfach kopieren oder verschieben. Beim ersten Start am neuen Ort erkennt RetroDaD den Umzug und schreibt eigene Titel, Cover, Favoriten, Spielzeiten und Spielstand-Zuordnungen auf den neuen Ort um (vorher wird jede Datei als `….vor-umzug-<Datum>` gesichert). Oben erscheint „RetroDaD ist umgezogen …“.

## Updates einspielen
**Automatisch:** Einstellungen → Allgemein → **RetroDaD-Update → Nach Updates suchen → Update laden**. RetroDaD holt die neueste Fassung (von github.com/Kuiki86/RetroDaD), legt sie in den Ordner `bin\Updates` und meldet „Update wird nach dem Neustart installiert“. Mit **Jetzt neu starten** (oder beim nächsten Start) wird es eingespielt. Einmal am Tag schaut RetroDaD selbst nach und meldet sich, wenn es etwas Neues gibt – geladen wird nur auf deinen Knopfdruck.

**Von Hand:**
1. Die neue `RetroDaD.zip` **ungeöffnet** in den Ordner `bin\Updates` legen.
2. RetroDaD starten. Es prüft die ZIP, spielt sie ein und startet sich neu; oben erscheint „Update eingespielt: RetroDaD …“.

Was dabei passiert:
- Ersetzt werden nur Programmdateien (`bin\launcher.py`, `bin\retrodad\…`, `bin\ui\…`, `bin\werkzeuge\…`, `RetroDaD.exe`, `LIESMICH.md` …). **Nie angefasst:** `Spiele`, `Spielstaende`, `Musik`, `bin\Emulatoren`, `bin\covers`, `bin\logs`, `bin\steuerung`, `bin\jsons` (außer `version.json`) und deine Schlüssel. Eigene Erfolgsbilder in `bin\ui\erfolge` bleiben; neue kommen dazu.
- Jede ersetzte Datei landet vorher in `bin\Updates\vorher-<Datum>` – damit lässt sich ein Update von Hand zurückdrehen. Geht beim Einspielen etwas schief, stellt RetroDaD den alten Stand sofort wieder her.
- Die eingespielte ZIP wandert nach `bin\Updates\installiert`, eine unbrauchbare (falsche Datei, beschädigt, verdächtige Pfade) nach `bin\Updates\nicht-eingespielt` – mit Hinweis beim Start. Gelöscht wird nichts.
- Liegen mehrere ZIPs da, nimmt RetroDaD die neueste.

---

## Wenn etwas nicht klappt
- **Spiel startet nicht**: Die Meldung in RetroDaD nennt die Ursache. Mehr steht in `bin\logs\<konsole>.log`.
- **Grafikfehler** (z. B. bei NES-Spielen falsche Sprites): Rechtsklick → **ROM prüfen**. Bei einem fehlerhaften Dateikopf hilft **Header reparieren** (vorher wird eine `.bak`-Sicherung angelegt). Alternativ über **Core ändern** einen anderen Emulator-Kern wählen.
- **Ränder flackern bei NES-Spielen**: Das passiert auch auf der echten Konsole. In RetroArch mit F1 → Core-Optionen → Overscan links und rechts auf 8 px stellen.
- **Einstellungsdatei beschädigt**: RetroDaD legt sie als `.kaputt-…` beiseite, nimmt die Standardwerte und zeigt einen Hinweis. Gelöscht wird nichts.

---

Hintergrund des Ladebildschirms: Vektorgrafik „Colorful blocks blank white background“ (Bild 67034), vom Nutzer bereitgestellt.
