# Übergang auf den neuen Ordner-Aufbau (3.12): startet bin\launcher.py.
# RetroDaD räumt diese Datei beim ersten Start selbst nach bin\Updates\vorher-umbau-<Datum>.
import os, runpy, sys
ziel = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bin", "launcher.py")
sys.argv[0] = ziel
sys.path.insert(0, os.path.dirname(ziel))
runpy.run_path(ziel, run_name="__main__")
